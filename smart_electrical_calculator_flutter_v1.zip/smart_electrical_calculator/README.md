# Smart Electrical Calculator (Flutter)

Aplikasi Flutter asas yang berfungsi dengan tiga profil:
- Awam & Pelajar
- Juruelektrik Domestik
- Jurutera Industri

## Keperluan
- Flutter SDK (Dart 3.3+)
- Android Studio atau VS Code

## Cara jalankan
1. Cipta projek Flutter kosong: `flutter create smart_electrical_calculator`
2. Gantikan `pubspec.yaml` dan folder `lib/` dengan kandungan pakej ini.
3. Jalankan:
   ```bash
   flutter pub get
   flutter run
   ```

## Modul tersedia
- Hukum Ohm: V, I, R dan P
- Kuasa elektrik: DC / 1 fasa / 3 fasa
- Susutan voltan anggaran kabel 1 fasa dan 3 fasa
- Arus beban 3 fasa
- Penukar unit asas

## Nota keselamatan
Keputusan ialah anggaran pendidikan/rekabentuk awal. Pemilihan kabel, fius/MCB, RCD,
pembumian dan pemasangan sebenar mesti disahkan oleh orang kompeten berdasarkan
piawaian serta peraturan tempatan terkini. Aplikasi ini bukan pengganti pemeriksaan
tapak atau pengiraan kejuruteraan yang disahkan.
