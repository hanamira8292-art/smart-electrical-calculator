import 'package:flutter/material.dart';
import 'core/constants/app_theme.dart';
import 'features/auth_profile/profile_selection_screen.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const SmartElectricalApp());
}

class SmartElectricalApp extends StatelessWidget {
  const SmartElectricalApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Smart Electrical Calculator',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.dark,
      home: const ProfileSelectionScreen(),
    );
  }
}
