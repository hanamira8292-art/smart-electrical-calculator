import 'package:flutter/material.dart';

class AppColors {
  static const navy = Color(0xFF101A35);
  static const royalBlue = Color(0xFF2457D6);
  static const electricYellow = Color(0xFFFFD600);
  static const surface = Color(0xFF192541);
  static const muted = Color(0xFF9EABC7);
  static const success = Color(0xFF43D9A3);
}
