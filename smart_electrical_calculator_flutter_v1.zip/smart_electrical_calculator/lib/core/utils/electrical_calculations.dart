import 'dart:math';

class ElectricalCalculations {
  static Map<String, double> ohms({double? voltage, double? current, double? resistance}) {
    if (voltage != null && current != null) {
      return {'R': voltage / current, 'P': voltage * current};
    }
    if (voltage != null && resistance != null) {
      return {'I': voltage / resistance, 'P': voltage * voltage / resistance};
    }
    if (current != null && resistance != null) {
      return {'V': current * resistance, 'P': current * current * resistance};
    }
    throw ArgumentError('Masukkan sekurang-kurangnya dua nilai: V, I atau R.');
  }

  static double dcPower(double voltage, double current) => voltage * current;

  static double singlePhasePower(double voltage, double current, double powerFactor) =>
      voltage * current * powerFactor;

  static double threePhasePower(double voltageLine, double current, double powerFactor) =>
      sqrt(3) * voltageLine * current * powerFactor;

  static double threePhaseCurrent(double powerW, double voltageLine, double powerFactor) =>
      powerW / (sqrt(3) * voltageLine * powerFactor);

  // Anggaran menggunakan rintangan konduktor sahaja; tidak mengambil kira reaktans.
  static double voltageDrop({
    required double current,
    required double lengthMetres,
    required double resistanceOhmPerKm,
    required bool threePhase,
  }) {
    final factor = threePhase ? sqrt(3) : 2.0;
    return factor * current * (lengthMetres / 1000) * resistanceOhmPerKm;
  }

  static double percentageDrop(double drop, double voltage) => drop / voltage * 100;
}
