String fmt(double value, {int decimals = 2}) {
  if (!value.isFinite) return 'Tidak sah';
  return value.toStringAsFixed(decimals);
}
