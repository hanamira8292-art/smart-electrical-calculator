import 'package:flutter/material.dart';
import '../shared/tool_menu.dart';

class PublicHomeScreen extends StatelessWidget {
  const PublicHomeScreen({super.key});
  @override
  Widget build(BuildContext context) => const ToolMenu(
    profileTitle: 'Awam & Pelajar',
    subtitle: 'Kenali konsep dan pengiraan asas elektrik.',
    tools: [
      {'title':'Kalkulator Hukum Ohm','desc':'Cari voltan, arus, rintangan dan kuasa menggunakan dua nilai diketahui.','type':'ohm','fields':['Voltan (V)','Arus (A)','Rintangan (Ω)'],'icon':Icons.functions},
      {'title':'Kuasa DC','desc':'Kuasa asas: P = V × I.','type':'power1','fields':['Voltan (V)','Arus (A)','Faktor kuasa (0–1)'],'icon':Icons.bolt},
      {'title':'Penukar unit kuasa','desc':'Tukar input watt kepada kW dan mW.','type':'converter','fields':['Nilai'],'icon':Icons.swap_vert},
    ],
  );
}
