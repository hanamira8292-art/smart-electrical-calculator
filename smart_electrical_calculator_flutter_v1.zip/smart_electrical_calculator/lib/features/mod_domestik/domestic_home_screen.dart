import 'package:flutter/material.dart';
import '../shared/tool_menu.dart';

class DomesticHomeScreen extends StatelessWidget {
  const DomesticHomeScreen({super.key});
  @override
  Widget build(BuildContext context) => const ToolMenu(
    profileTitle: 'Juruelektrik Domestik',
    subtitle: 'Alat anggaran awal untuk sistem elektrik kediaman.',
    tools: [
      {'title':'Hukum Ohm','desc':'Pengiraan voltan, arus, rintangan dan kuasa.','type':'ohm','fields':['Voltan (V)','Arus (A)','Rintangan (Ω)'],'icon':Icons.functions},
      {'title':'Kuasa 1 fasa','desc':'Kuasa aktif P = V × I × PF.','type':'power1','fields':['Voltan (V)','Arus (A)','Faktor kuasa (0–1)'],'icon':Icons.electrical_services},
      {'title':'Susutan voltan 1 fasa','desc':'Anggaran rintangan konduktor sahaja; masukkan rintangan Ω/km daripada data kabel.','type':'drop1','fields':['Arus (A)','Panjang sehala (m)','Rintangan konduktor (Ω/km)','Voltan bekalan (V)'],'icon':Icons.cable},
    ],
  );
}
