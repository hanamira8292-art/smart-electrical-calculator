import 'package:flutter/material.dart';
import '../mod_awam/public_home_screen.dart';
import '../mod_domestik/domestic_home_screen.dart';
import '../mod_industri/industrial_home_screen.dart';
import '../../core/constants/app_colors.dart';

class ProfileSelectionScreen extends StatelessWidget {
  const ProfileSelectionScreen({super.key});

  void _open(BuildContext context, String profile) {
    final Widget page = switch (profile) {
      'awam' => const PublicHomeScreen(),
      'domestik' => const DomesticHomeScreen(),
      _ => const IndustrialHomeScreen(),
    };
    Navigator.push(context, MaterialPageRoute(builder: (_) => page));
  }

  @override
  Widget build(BuildContext context) {
    final profiles = [
      ('awam', Icons.school_rounded, 'Awam & Pelajar', 'Belajar asas elektrik dan formula'),
      ('domestik', Icons.home_work_rounded, 'Juruelektrik Domestik', 'Pengiraan asas pemasangan rumah'),
      ('industri', Icons.factory_rounded, 'Jurutera Industri', 'Beban, kuasa dan sistem 3 fasa'),
    ];
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(22),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const SizedBox(height: 28),
            const Icon(Icons.bolt_rounded, color: AppColors.electricYellow, size: 48),
            const SizedBox(height: 16),
            const Text('SMART ELECTRICAL', style: TextStyle(fontSize: 13, letterSpacing: 2, color: AppColors.muted)),
            const Text('Calculator', style: TextStyle(fontSize: 34, fontWeight: FontWeight.w900)),
            const SizedBox(height: 10),
            const Text('Pilih profil untuk memaparkan alat pengiraan yang sesuai.', style: TextStyle(color: AppColors.muted)),
            const SizedBox(height: 28),
            ...profiles.map((p) => Card(
              margin: const EdgeInsets.only(bottom: 14),
              child: ListTile(
                contentPadding: const EdgeInsets.all(16),
                leading: CircleAvatar(
                  backgroundColor: AppColors.royalBlue,
                  child: Icon(p.$2, color: Colors.white),
                ),
                title: Text(p.$3, style: const TextStyle(fontWeight: FontWeight.bold)),
                subtitle: Padding(
                  padding: const EdgeInsets.only(top: 5),
                  child: Text(p.$4, style: const TextStyle(color: AppColors.muted)),
                ),
                trailing: const Icon(Icons.arrow_forward_ios, size: 16, color: AppColors.electricYellow),
                onTap: () => _open(context, p.$1),
              ),
            )),
            const Spacer(),
            const Text('Gunakan keputusan sebagai panduan awal sahaja.', style: TextStyle(fontSize: 11, color: AppColors.muted)),
          ]),
        ),
      ),
    );
  }
}
