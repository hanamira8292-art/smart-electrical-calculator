import 'package:flutter/material.dart';
import '../shared/tool_menu.dart';

class IndustrialHomeScreen extends StatelessWidget {
  const IndustrialHomeScreen({super.key});
  @override
  Widget build(BuildContext context) => const ToolMenu(
    profileTitle: 'Jurutera Industri',
    subtitle: 'Pengiraan kuasa dan beban sistem tiga fasa.',
    tools: [
      {'title':'Kuasa 3 fasa','desc':'P = √3 × V talian × I × faktor kuasa.','type':'power3','fields':['Voltan talian (V)','Arus (A)','Faktor kuasa (0–1)'],'icon':Icons.factory},
      {'title':'Arus 3 fasa','desc':'Anggar arus daripada kuasa aktif, voltan talian dan faktor kuasa.','type':'current3','fields':['Kuasa (W)','Voltan talian (V)','Faktor kuasa (0–1)'],'icon':Icons.electric_meter},
      {'title':'Susutan voltan 3 fasa','desc':'Anggaran menggunakan rintangan konduktor sahaja; tidak termasuk reaktans.','type':'drop3','fields':['Arus (A)','Panjang sehala (m)','Rintangan konduktor (Ω/km)','Voltan bekalan (V)'],'icon':Icons.cable},
      {'title':'Hukum Ohm','desc':'Pengiraan asas V, I, R dan P.','type':'ohm','fields':['Voltan (V)','Arus (A)','Rintangan (Ω)'],'icon':Icons.functions},
    ],
  );
}
