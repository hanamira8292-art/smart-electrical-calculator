import 'package:flutter/material.dart';
import 'calculator_page.dart';
import '../../core/constants/app_colors.dart';

class ToolMenu extends StatelessWidget {
  final String profileTitle;
  final String subtitle;
  final List<Map<String, dynamic>> tools;
  const ToolMenu({super.key, required this.profileTitle, required this.subtitle, required this.tools});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(profileTitle), actions: [
        IconButton(tooltip: 'Tukar profil', onPressed: () => Navigator.pop(context), icon: const Icon(Icons.swap_horiz_rounded)),
      ]),
      body: ListView(padding: const EdgeInsets.all(18), children: [
        Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(22),
            gradient: const LinearGradient(colors: [AppColors.royalBlue, AppColors.navy]),
          ),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Icon(Icons.electric_bolt_rounded, color: AppColors.electricYellow, size: 32),
            const SizedBox(height: 12),
            Text(profileTitle, style: const TextStyle(fontSize: 23, fontWeight: FontWeight.w900)),
            const SizedBox(height: 6),
            Text(subtitle, style: const TextStyle(color: Colors.white70)),
          ]),
        ),
        const SizedBox(height: 22),
        const Text('ALAT PENGIRAAN', style: TextStyle(color: AppColors.muted, letterSpacing: 1.3, fontWeight: FontWeight.bold)),
        const SizedBox(height: 10),
        ...tools.map((tool) => Card(
          margin: const EdgeInsets.only(bottom: 11),
          child: ListTile(
            contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 9),
            leading: CircleAvatar(backgroundColor: AppColors.royalBlue, child: Icon(tool['icon'] as IconData, color: Colors.white)),
            title: Text(tool['title'] as String, style: const TextStyle(fontWeight: FontWeight.bold)),
            subtitle: Text(tool['desc'] as String, style: const TextStyle(color: AppColors.muted)),
            trailing: const Icon(Icons.chevron_right, color: AppColors.electricYellow),
            onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => CalculatorPage(
              title: tool['title'] as String,
              description: tool['desc'] as String,
              fields: (tool['fields'] as List).cast<String>(),
              type: tool['type'] as String,
            ))),
          ),
        )),
        const SizedBox(height: 12),
        const Text('Peringatan: pengiraan kabel dan perlindungan mesti disahkan mengikut piawaian serta keadaan pemasangan sebenar.', style: TextStyle(color: AppColors.muted, fontSize: 11)),
      ]),
    );
  }
}
