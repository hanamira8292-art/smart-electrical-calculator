import 'package:flutter/material.dart';
import '../../core/utils/electrical_calculations.dart';
import '../../core/utils/number_format.dart';
import '../../core/constants/app_colors.dart';

class CalculatorPage extends StatefulWidget {
  final String title;
  final String description;
  final List<String> fields;
  final String type;
  const CalculatorPage({super.key, required this.title, required this.description,
    required this.fields, required this.type});

  @override
  State<CalculatorPage> createState() => _CalculatorPageState();
}

class _CalculatorPageState extends State<CalculatorPage> {
  final Map<String, TextEditingController> controllers = {};
  String result = 'Masukkan nilai dan tekan Kira.';
  String error = '';

  @override
  void initState() {
    super.initState();
    for (final field in widget.fields) {
      controllers[field] = TextEditingController();
    }
  }

  @override
  void dispose() {
    for (final c in controllers.values) { c.dispose(); }
    super.dispose();
  }

  double? value(String key) {
    final raw = controllers[key]?.text.trim() ?? '';
    if (raw.isEmpty) return null;
    return double.tryParse(raw.replaceAll(',', '.'));
  }

  void calculate() {
    FocusScope.of(context).unfocus();
    try {
      String output;
      switch (widget.type) {
        case 'ohm':
          final v = value('Voltan (V)');
          final i = value('Arus (A)');
          final r = value('Rintangan (Ω)');
          final map = ElectricalCalculations.ohms(voltage: v, current: i, resistance: r);
          output = map.entries.map((e) => '${e.key}: ${fmt(e.value)} ${e.key == 'R' ? 'Ω' : e.key == 'I' ? 'A' : e.key == 'V' ? 'V' : 'W'}').join('\n');
          break;
        case 'power1':
          final p = ElectricalCalculations.singlePhasePower(value('Voltan (V)')!, value('Arus (A)')!, value('Faktor kuasa (0–1)')!);
          output = 'Kuasa aktif: ${fmt(p)} W\n(${fmt(p / 1000)} kW)';
          break;
        case 'power3':
          final p = ElectricalCalculations.threePhasePower(value('Voltan talian (V)')!, value('Arus (A)')!, value('Faktor kuasa (0–1)')!);
          output = 'Kuasa aktif 3 fasa: ${fmt(p)} W\n(${fmt(p / 1000)} kW)';
          break;
        case 'current3':
          final i = ElectricalCalculations.threePhaseCurrent(value('Kuasa (W)')!, value('Voltan talian (V)')!, value('Faktor kuasa (0–1)')!);
          output = 'Arus talian anggaran: ${fmt(i)} A';
          break;
        case 'drop1':
        case 'drop3':
          final drop = ElectricalCalculations.voltageDrop(
            current: value('Arus (A)')!,
            lengthMetres: value('Panjang sehala (m)')!,
            resistanceOhmPerKm: value('Rintangan konduktor (Ω/km)')!,
            threePhase: widget.type == 'drop3',
          );
          final pct = ElectricalCalculations.percentageDrop(drop, value('Voltan bekalan (V)')!);
          output = 'Susutan voltan: ${fmt(drop)} V\nPeratus susutan: ${fmt(pct)}%';
          break;
        case 'converter':
          final v = value('Nilai')!;
          output = 'Watt: ${fmt(v)} W\nKilowatt: ${fmt(v / 1000)} kW\nMilliwatt: ${fmt(v * 1000)} mW';
          break;
        default:
          output = 'Modul belum tersedia.';
      }
      setState(() { result = output; error = ''; });
    } catch (_) {
      setState(() { error = 'Sila masukkan nilai nombor yang sah dan lengkap. Untuk Hukum Ohm, isi sekurang-kurangnya dua daripada V, I atau R.'; });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.title)),
      body: ListView(padding: const EdgeInsets.all(18), children: [
        Text(widget.description, style: const TextStyle(color: AppColors.muted)),
        const SizedBox(height: 20),
        ...widget.fields.map((f) => Padding(
          padding: const EdgeInsets.only(bottom: 13),
          child: TextField(
            controller: controllers[f],
            keyboardType: const TextInputType.numberWithOptions(decimal: true),
            decoration: InputDecoration(labelText: f, prefixIcon: const Icon(Icons.edit_rounded)),
          ),
        )),
        ElevatedButton.icon(onPressed: calculate, icon: const Icon(Icons.calculate_rounded), label: const Text('KIRA SEKARANG')),
        if (error.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 14), child: Text(error, style: const TextStyle(color: Colors.orangeAccent))),
        const SizedBox(height: 18),
        Card(child: Padding(
          padding: const EdgeInsets.all(18),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('KEPUTUSAN', style: TextStyle(color: AppColors.electricYellow, fontWeight: FontWeight.bold, letterSpacing: 1)),
            const SizedBox(height: 12),
            SelectableText(result, style: const TextStyle(fontSize: 17, height: 1.6, fontWeight: FontWeight.w600)),
          ]),
        )),
      ]),
    );
  }
}
